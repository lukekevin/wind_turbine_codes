# wind_turbine_codes
A collection of codes developed for the group project guided by me at seven square academy.
