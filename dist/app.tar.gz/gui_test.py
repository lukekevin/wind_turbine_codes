import random
from time import sleep

def main(variable):
        for i in range(100):
                data = random.randint(1,100)
                variable.value = data




